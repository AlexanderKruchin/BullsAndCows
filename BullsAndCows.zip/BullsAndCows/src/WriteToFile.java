import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WriteToFile {

    public static void writeToFile(int gameNum, int countAtt, String lineUser, String computerNumber, String mesForUser, boolean winOrLose) throws IOException {

        /**
         * gameNum - номер игры
         * countAtt - количество попыток пользователя
         * lineUser - ввод пользователя
         * computerNumber - цифра компьютера
         * mesForUser - сообщения пользователю о быках и коровах
         */

        Date dated = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");

        if (countAtt == 1 & winOrLose) {
            FileWriter fileWriter = new FileWriter("ЛогиИгрыБыкиИКоровы.txt", true);
            fileWriter.write("Game №" + gameNum +" "+ simpleDateFormat.format(dated) + " Загаданная строка " + computerNumber + " \n");
            fileWriter.write("Запрос: " + lineUser + " Ответ: " + mesForUser + " \n");
            fileWriter.write("Строка была угадана за " + countAtt + " попытку.\n");
            fileWriter.flush();
            fileWriter.close();
        }
        if (countAtt == 1 & !winOrLose){
            FileWriter fileWriter = new FileWriter("ЛогиИгрыБыкиИКоровы.txt", true);
            fileWriter.write("Game №" + gameNum +" "+ simpleDateFormat.format(dated) + " Загаданная строка " + computerNumber + " \n");
            fileWriter.write("Запрос: " + lineUser + " Ответ: " + mesForUser + " \n");
            fileWriter.flush();
            fileWriter.close();
        }
        if (countAtt > 1 & !winOrLose){
            FileWriter fileWriter = new FileWriter("ЛогиИгрыБыкиИКоровы.txt", true);
            fileWriter.write("Запрос: " + lineUser + " Ответ: " + mesForUser + " \n");
            fileWriter.flush();
            fileWriter.close();
        }else if (countAtt > 1 & winOrLose){
            FileWriter fileWriter = new FileWriter("ЛогиИгрыБыкиИКоровы.txt", true);
            fileWriter.write("Запрос: " + lineUser + " Ответ: " + mesForUser + " \n");
            fileWriter.write("Строка была угадана за " + countAtt + " попытку. \n");
            fileWriter.flush();
            fileWriter.close();
        }


//        String s = "Game №" + 1 + " " + simpleDateFormat.format(dated) + " Загаданная строка " + 0123;
//        String ss = "Запрос: " + 3510 + " Ответ: " + 2 + " Коровы " + 1 + " Бык";
//        String sss = "Строка была угадана за " + 5 + " попыток.";
    }
}
// Game №1 05.08.2022 6:46 Загаданная строка 0123
// Запрос: 3510 Ответ: 2 Коровы 1 Бык
// Запрос: 3510 Ответ: 2 Коровы 1 Бык
// ....
// Строка была угадана за 5 попыток.
/**
нужны цифры:
 кол-во попыток+
 запрос юзера+
 ответ системы на запрос юзера+
 цифра придуманная компьютером+
 номер игры+

 */
